import numpy as np

a =[[[547., 343.],[424., 342.],[429., 218.],[552., 219.]]], [[[380., 342.]
,[255., 344.],[255., 216.],[383., 217.]]],[[[208., 344.]
,[ 78., 343.],[ 75., 213.],[208., 215.]]]

print ((547+424+429+552)/4)
print ((343+342+218+219)/4)
print ((380+255+255+383)/4)
print ((342+344+216+217)/4)
print len(a)
print "cat"

ilimit = len(a)
i,j,k=0,0,0
midpointArray = [[0 for x in range(2)] for y in range(ilimit)]

print midpointArray

for i in range(0,ilimit):
    for k in range(0,2):
        sumval=0
        for j in range(0,4):
            sumval =sumval+a[i][0][j][k]
            midpointArray[i][k]=sumval/4
            #print sumx

print midpointArray

class ReMarker:
  def __init__(self, number, midpoint, target, visibility):
    self.number = IDnumber
    self.Midpoint = (midx,midy)
    self.Target = (tx,ty)
    self.Visibility= u#bool
#class marker:
 #   def __init__(self, name, distance):
  #      self.aidie
   #     self.midpoint






   b=[[0],[3],[6]]
flat = [item for sublist in b for item in sublist]
s=set(flat)
print s
c=((1,2),(3,4),(5,6))
d=[[9,8],[7,6],[5,4],[8,9],[10,11],[13,14],(1,2)]

print 0 in s

markerlist= []

class ReMarker:
  def __init__(self, Number=None, Target=None, Isin=None):
    self.Number = IDnumber
    #self.Midpoint = (midx,midy)
    self.Target = (tx,ty)
    self.Isin = u


noOfElems = len(d)
for i in range (0,noOfElems):
    IDnumber=i
    tx=d[i][0]
    ty=d[i][1]
    u = i in s
    markerlist.append(ReMarker(IDnumber,(tx,ty),u))

cat=len(markerlist)
print cat
for i in range (0,cat):
    print markerlist[i].Isin
