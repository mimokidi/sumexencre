﻿using System;

namespace helloworld
{
    class Program
    {
        static void Main(string[] args)
        {
            var cat = Console.ReadLine();
        
            Console.WriteLine("Hello World!");
            Console.WriteLine(cat);
        }
    }
}
