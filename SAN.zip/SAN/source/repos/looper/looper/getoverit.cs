﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.DesignScript.Geometry;
using Autodesk.DesignScript.Interfaces;
using Autodesk.DesignScript.Runtime;

namespace looper
{
    public class Curves
    {
        public List<Autodesk.DesignScript.Geometry.Curve> cats = new List<Autodesk.DesignScript.Geometry.Curve>();

        public static int toco(List<Curve> cats)
        {
            int toco = cats.Count;
            return toco;
        }
        public static List<Curve> pointArray (List<Curve> cats)
        {
            for (int i = cats.Count - 1; i >= 0; i--)
            {
                Curve a = cats[i];
                List<Autodesk.DesignScript.Geometry.Curve> pointArray = new List<Autodesk.DesignScript.Geometry.Curve>();
                List<Autodesk.DesignScript.Geometry.Curve> nocat = new List<Autodesk.DesignScript.Geometry.Curve>();
                nocat = cats;
                a = cats[i];
                nocat = cats.RemoveAt(i);
                pointArray[i] =  a.Intersect(nocat);
                cats.dispose();



            }
            return pointArray;
        }
    }
}
