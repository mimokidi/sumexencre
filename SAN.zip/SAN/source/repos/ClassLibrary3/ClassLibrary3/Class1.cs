﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.DesignScript.Interfaces;
using Autodesk.DesignScript.Geometry;
using Autodesk.DesignScript.Runtime;


namespace SecondaryDataSorting
{
    public class ListVals 
    {
        [MultiReturn(new[] { "Count:", "Lengths:" })]
        public static Dictionary<string,object> Uniques(IEnumerable<double> lengths, int roundingLimit)
        {
          
            List<double> bufferForRounding = lengths.ToList();
            List<double> rounded = new List<double>();
            List<int> times = new List<int>();
            IEnumerable<int> holdit = lengths.Cast<int>();
            
            
            foreach (double val in bufferForRounding)
            {
                double cat = Math.Round(val, roundingLimit);
                rounded.Add(cat);
               
            }

            IEnumerable<double> uniqueItems = rounded.Distinct<double>();

            
            IEnumerable<double> roundedIE = rounded;

            var counts = rounded.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());

            // IEnumerable<int> arkana = counts.Values;
            Dictionary<double, int> arkana = counts;
            //return arkana;*/
            return new Dictionary<string, object>
                {

                { "Lengths:", arkana.Keys},
                { "Count:" , arkana.Values}
                    
                    
                };
                
            
           
        }

    }
}
 