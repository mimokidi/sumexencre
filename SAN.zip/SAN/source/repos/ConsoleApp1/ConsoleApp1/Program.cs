﻿using System;
using System.Linq;
using Microsoft.CSharp.RuntimeBinder;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            for (i = 0; i < 10, i++)
            {
                List<int> cat = new list<int>();
            }
        }
    }
}
