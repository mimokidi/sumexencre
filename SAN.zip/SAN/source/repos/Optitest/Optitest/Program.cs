﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Optitest
{
    class Program
    {
        static void Main(string[] args)
        {
            int stockLength;
            Console.WriteLine("stocklength:");
            stockLength = Convert.ToInt16(Console.ReadLine());
            int[] briefList = new int[10];
            

            var pieces = new List<Piece>();
            var cutsLP = new List<CutConfig>();

            //this is where we generate the list of lengths
            for (int i = 0; i < 10; i++)
            {
                var newPiece = new Piece();

                Random listItem = new Random(i);
                int listItemInt = listItem.Next(20);
                Random itemCount = new Random(i);
                int itemCountInt = itemCount.Next(50);
                newPiece.Id = i;
                newPiece.Length = listItemInt;
                newPiece.Count = itemCountInt;
                pieces.Add(newPiece);

            }

           
            foreach (var piece in pieces)
            {
                piece.CountPerStock = stockLength / piece.Length;
                piece.StockUse = piece.Count / piece.CountPerStock;
                piece.Remainder = stockLength - (piece.Length * piece.CountPerStock);

                Console.WriteLine("id: {0}  length: {1} count {2} intcuts:{3} remainder:{4}", piece.Id, piece.Length, piece.Count, piece.CountPerStock, piece.Remainder);
                var lpCut = new CutConfig
                {
                    configVec = new int[pieces.Count]
                };
                int vecIndex = pieces.IndexOf(piece);
                lpCut.configVec[vecIndex] = piece.CountPerStock;
                cutsLP.Add(lpCut);
                Console.WriteLine(string.Join(",",lpCut.configVec));
//                Console.WriteLine("id: {0} ", Convert.ToString (lpCut.configVec));


            }
            int TotalstockUse = pieces.Sum(piece => piece.StockUse);
            Console.WriteLine("total use:{0}", TotalstockUse);

            
       

        }
        
     
    }
    class Piece
    {
        public int Id;
        public int Length;
        public int Count;
        public int StockUse;
        public int CountPerStock;
        public int Remainder;
    }
    class CutConfig
    {
        public int[] configVec;
    }
}
