﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.DesignScript.Geometry;
using Autodesk.DesignScript.Interfaces;
using Autodesk.DesignScript.Runtime;

namespace failings
{
    public class badBad
    {


        public static List<List<Geometry>> intersectWithOthers(Geometry set1, List<Geometry> set2)
        {

            var outPut = new List<List<Geometry>>();
            foreach (var item in set2)
            {
                outPut.Add(set1.Intersect(item).ToList());
            }
            return outPut;

        }
        public static List<List<Geometry>> fullPoints (Geometry set1,Geometry set2)


    }
}