﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Autodesk.DesignScript.Geometry;
using Autodesk.DesignScript.Interfaces;
using Autodesk.DesignScript.Runtime;

namespace failings
{
    public class CatBad
    {


        public static List<List<Geometry>> IntersectWithOthers(Geometry set1, List<Geometry> set2)
        {

            var outPut = new List<List<Geometry>>();
            foreach (var item in set2)
            {
                outPut.Add(set1.Intersect(item).ToList());
            }
            return outPut;

        }
        //yields 32 (real) * 8
        public static List<List<double>> ParamOfIntersection(List<Line> partIntersected, List<List<Point>> pointOnCurve)
        {
            var pointParam = new List<List<double>>();
            var pointsJuggle = pointOnCurve.ToList();
            int x = 0;

            for (x=0; x<(partIntersected.Count()); x++)
            {   
              
                foreach (var pointSet in pointOnCurve)
                {
                    List<double> catlist = new List<double>();
                    foreach (var catItem in pointSet)
                    { 
                        double catpos;

                        catpos = partIntersected[x].ParameterAtPoint(catItem);
                        catlist.Add(catpos);
                    
                    }
                    pointParam.Add(catlist);
                }

            }
            return pointParam;
        }

        public static List<List<Int32>> Occlusions(IEnumerable<Geometry> fullSet)
        {
            var exList = new List<List<Int32>>();
            var solipsList = fullSet.ToList();
            int end = fullSet.Count() - 1;
           
            
            foreach (var item in fullSet)
            {
                int current = solipsList.IndexOf(item);
                var clippedlist = new List<Int32>();
                solipsList.RemoveAt(current);
                clippedlist[current] = solipsList.Count();
              
                exList.Add(clippedlist);
            }
            return exList;
        }


       /* public static List<List<Curve>> ListStrangeness (List<Curve> fullSet)
        {
            
            int end = fullSet.Count() - 1;
            int i = end;
            List<List<Curve>> occludedList = new List<List<Curve>>();
            for (i = 0; i >= end ; i++)
            {
                List<Curve> tarantaBabu = new List<Curve>();
                tarantaBabu = fullSet.RemoveAt(i);
                tarantaBabu.RemoveAt(i);
                occludedList[i]=tarantaBabu;
                return occludedList;
            }
            return occludedList;           
        }*/



    }
}