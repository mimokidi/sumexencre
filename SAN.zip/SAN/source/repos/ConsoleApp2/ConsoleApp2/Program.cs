﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        
        static void Main(string[] args)
        {
            int[] arrayOfNumbers = new int[10];
            int i = 0;
            List<int> cat = new List<int>();
            for (i = 0; i < 10; i++)
            {

                int x = i;
                arrayOfNumbers[i] = x;
                Console.WriteLine("this is i");
                Console.WriteLine(x);
                List<int> listOfNumbers = arrayOfNumbers.ToList();
                Console.WriteLine(listOfNumbers.IndexOf(i));

            }
        }
        
      

        
    }
}
